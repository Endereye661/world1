import { FAST_MODE } from "./../../../config.js";
import { assertCuboidSelection, assertCanBuildWithin } from "./../../modules/assert.js";
import { Jobs } from "./../../modules/jobs.js";
import { RawText, regionIterateBlocks, Vector } from "./../../../library/Minecraft.js";
import { MinecraftBlockTypes } from "mojang-minecraft";
import { registerCommand } from "../register_commands.js";
const registerInformation = {
    name: "copy",
    permission: "worldedit.clipboard.copy",
    description: "commands.wedit:copy.description",
    usage: [
        {
            flag: "a"
        }, {
            flag: "e"
        }, {
            flag: "m",
            name: "mask",
            type: "Mask"
        }
    ]
};
/**
 * Performs the ;copy command.
 * @remark This function is only exported so as to not duplicate code for the ;cut command.
 * @param session The session whose player is running this command
 * @param args The arguments that change how the copying will happen
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function* copy(session, args = new Map()) {
    assertCuboidSelection(session);
    const player = session.getPlayer();
    const dimension = player.dimension;
    const [start, end] = session.selection.getRange();
    assertCanBuildWithin(player, start, end);
    const includeEntities = args.get("_using_item") ? session.includeEntities : args.has("e");
    const includeAir = args.get("_using_item") ? session.includeAir : !args.has("a");
    const mask = args.has("m") ? args.get("m-mask") : undefined;
    if (session.clipboard) {
        session.deleteRegion(session.clipboard);
    }
    session.clipboard = session.createRegion(!FAST_MODE);
    session.clipboardTransform = {
        rotation: Vector.ZERO,
        flip: Vector.ONE,
        originalLoc: Vector.add(start, end).mul(0.5),
        relative: Vector.sub(Vector.add(start, end).mul(0.5), Vector.from(player.location).floor())
    };
    let error = false;
    if (session.clipboard.isAccurate) {
        const airBlock = MinecraftBlockTypes.air.createDefaultBlockPermutation();
        const filter = mask || !includeAir;
        yield "Copying blocks...";
        const blocks = (loc) => {
            const wasAir = dimension.getBlock(loc).id == "minecraft:air";
            const isAir = wasAir || (mask ? !mask.matchesBlock(loc, dimension) : false);
            if (includeAir && mask && !wasAir && isAir) {
                return airBlock;
            }
            else if (!includeAir && isAir) {
                return false;
            }
            return true;
        };
        error = yield* session.clipboard.saveProgressive(start, end, dimension, { includeEntities }, filter ? blocks : "all");
    }
    else {
        // Create a temporary copy since we'll be adding void/air blocks to the selection.
        const tempUsed = !includeAir || mask;
        const temp = session.createRegion(false);
        if (tempUsed) {
            temp.save(start, end, dimension);
            const voidBlock = MinecraftBlockTypes.structureVoid.createDefaultBlockPermutation();
            const airBlock = MinecraftBlockTypes.air.createDefaultBlockPermutation();
            for (const block of regionIterateBlocks(start, end)) {
                const wasAir = dimension.getBlock(block).id == "minecraft:air";
                const isAir = wasAir || (mask ? !mask.matchesBlock(block, dimension) : false);
                if (includeAir && mask && !wasAir && isAir) {
                    dimension.getBlock(block).setPermutation(airBlock);
                }
                else if (!includeAir && isAir) {
                    dimension.getBlock(block).setPermutation(voidBlock);
                }
            }
        }
        error = session.clipboard.save(start, end, dimension, { includeEntities });
        if (tempUsed) {
            temp.load(start, dimension);
            session.deleteRegion(temp);
        }
    }
    return error;
}
registerCommand(registerInformation, function* (session, builder, args) {
    const job = Jobs.startJob(session, 1, session.selection.getRange());
    try {
        if (yield* Jobs.perform(job, copy(session, args))) {
            throw RawText.translate("commands.generic.wedit:commandFail");
        }
    }
    finally {
        Jobs.finishJob(job);
    }
    return RawText.translate("commands.wedit:copy.explain").with(`${session.selection.getBlockCount()}`);
});
